package com.example

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import com.example.localization.AppLanguage
import com.example.service.AppLockService
import com.example.ui.navigation.Screen
import com.example.ui.screens.AppLockScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DocumentAndFileVaultScreen
import com.example.ui.screens.DocumentViewerScreen
import com.example.ui.screens.FolderManageScreen
import com.example.ui.screens.LockScreen
import com.example.ui.screens.PhotoVaultScreen
import com.example.ui.screens.PhotoViewerScreen
import com.example.ui.screens.RecoveryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SetupPinScreen
import com.example.ui.screens.TrashScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.VideoVaultScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.VaultViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : FragmentActivity() {
    private val viewModel: VaultViewModel by viewModels()
    private var lastBackgroundTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Apply FLAG_SECURE according to user preferences
        if (viewModel.securityPrefs.flagSecureEnabled) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }

        // Start AppLockService if permissions are available
        tryStartAppLockService()

        setContent {
            val language by viewModel.language.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val themeMode by viewModel.themeMode.collectAsState()
            val flagSecure by viewModel.flagSecureEnabled.collectAsState()

            val isDark = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme()
            }

            // Update window FLAG_SECURE dynamically
            LaunchedEffect(flagSecure) {
                if (flagSecure) {
                    window.setFlags(
                        WindowManager.LayoutParams.FLAG_SECURE,
                        WindowManager.LayoutParams.FLAG_SECURE
                    )
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            // Listen for toast messages
            LaunchedEffect(Unit) {
                viewModel.toastMessage.collectLatest { message ->
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                }
            }

            // Handle back navigation
            BackHandler(enabled = true) {
                val screen = currentScreen
                when (screen) {
                    is Screen.Lock -> finish()
                    is Screen.Dashboard -> finish()
                    is Screen.SetupPin -> {
                        if (screen.isChangePin) {
                            viewModel.navigateBack()
                        } else {
                            finish()
                        }
                    }
                    else -> {
                        if (!viewModel.navigateBack()) {
                            finish()
                        }
                    }
                }
            }

            MyApplicationTheme(darkTheme = isDark) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(
                        viewModel = viewModel,
                        currentScreen = currentScreen,
                        language = language
                    )
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        lastBackgroundTime = System.currentTimeMillis()
        if (viewModel.isUnlocked.value) {
            val timeoutSeconds = viewModel.autoLockTimeout.value
            if (timeoutSeconds == 0) {
                viewModel.lockVault()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (viewModel.isUnlocked.value && lastBackgroundTime > 0L) {
            val timeoutSeconds = viewModel.autoLockTimeout.value
            if (timeoutSeconds > 0) {
                val elapsedSeconds = (System.currentTimeMillis() - lastBackgroundTime) / 1000
                if (elapsedSeconds >= timeoutSeconds) {
                    viewModel.lockVault()
                }
            }
        }
        tryStartAppLockService()
    }

    private fun tryStartAppLockService() {
        try {
            if (viewModel.appLockRepository.hasUsageStatsPermission() &&
                viewModel.appLockRepository.hasOverlayPermission()
            ) {
                val serviceIntent = Intent(this, AppLockService::class.java)
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

@Composable
fun AppNavigation(
    viewModel: VaultViewModel,
    currentScreen: Screen,
    language: AppLanguage
) {
    when (currentScreen) {
        is Screen.Lock -> {
            LockScreen(
                viewModel = viewModel,
                language = language,
                onLanguageToggle = {
                    val nextLang = if (language == AppLanguage.ENGLISH) AppLanguage.GUJARATI else AppLanguage.ENGLISH
                    viewModel.setLanguage(nextLang)
                },
                onForgotPinClick = { viewModel.navigateTo(Screen.Recovery) }
            )
        }

        is Screen.SetupPin -> {
            SetupPinScreen(
                viewModel = viewModel,
                isChangePin = currentScreen.isChangePin,
                language = language,
                onBackClick = if (currentScreen.isChangePin) {
                    { viewModel.navigateBack() }
                } else null
            )
        }

        is Screen.Recovery -> {
            RecoveryScreen(
                viewModel = viewModel,
                language = language,
                onBackClick = { viewModel.navigateBack() }
            )
        }

        is Screen.Dashboard -> {
            DashboardScreen(
                viewModel = viewModel,
                language = language,
                onNavigate = { screen -> viewModel.navigateTo(screen) },
                onLanguageToggle = {
                    val nextLang = if (language == AppLanguage.ENGLISH) AppLanguage.GUJARATI else AppLanguage.ENGLISH
                    viewModel.setLanguage(nextLang)
                },
                onLockClick = { viewModel.lockVault() }
            )
        }

        is Screen.Photos -> {
            PhotoVaultScreen(
                viewModel = viewModel,
                folderId = currentScreen.folderId,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onPhotoClick = { id -> viewModel.navigateTo(Screen.PhotoViewer(id)) }
            )
        }

        is Screen.Videos -> {
            VideoVaultScreen(
                viewModel = viewModel,
                folderId = currentScreen.folderId,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onVideoClick = { id -> viewModel.navigateTo(Screen.VideoPlayer(id)) }
            )
        }

        is Screen.Documents -> {
            DocumentAndFileVaultScreen(
                viewModel = viewModel,
                isDocumentsOnly = true,
                folderId = currentScreen.folderId,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onItemClick = { id -> viewModel.navigateTo(Screen.DocumentViewer(id)) }
            )
        }

        is Screen.Files -> {
            DocumentAndFileVaultScreen(
                viewModel = viewModel,
                isDocumentsOnly = false,
                folderId = currentScreen.folderId,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onItemClick = { id -> viewModel.navigateTo(Screen.DocumentViewer(id)) }
            )
        }

        is Screen.Folders -> {
            FolderManageScreen(
                viewModel = viewModel,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onOpenFolder = { screen -> viewModel.navigateTo(screen) }
            )
        }

        is Screen.Trash -> {
            TrashScreen(
                viewModel = viewModel,
                language = language,
                onBackClick = { viewModel.navigateBack() }
            )
        }

        is Screen.AppLock -> {
            AppLockScreen(
                viewModel = viewModel,
                language = language,
                onBackClick = { viewModel.navigateBack() }
            )
        }

        is Screen.Settings -> {
            SettingsScreen(
                viewModel = viewModel,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onChangePinClick = { viewModel.navigateTo(Screen.SetupPin(isChangePin = true)) }
            )
        }

        is Screen.PhotoViewer -> {
            PhotoViewerScreen(
                viewModel = viewModel,
                itemId = currentScreen.itemId,
                language = language,
                onBackClick = { viewModel.navigateBack() }
            )
        }

        is Screen.VideoPlayer -> {
            VideoPlayerScreen(
                viewModel = viewModel,
                itemId = currentScreen.itemId,
                language = language,
                onBackClick = { viewModel.navigateBack() }
            )
        }

        is Screen.DocumentViewer -> {
            DocumentViewerScreen(
                viewModel = viewModel,
                itemId = currentScreen.itemId,
                language = language,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    }
}
