package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.LockedApp
import com.example.data.model.VaultFolder
import com.example.data.model.VaultItem
import com.example.data.model.VaultStats
import com.example.data.repository.AppLockRepository
import com.example.data.repository.InstalledAppInfo
import com.example.data.repository.VaultRepository
import com.example.data.security.SecurityPreferences
import com.example.localization.AppLanguage
import com.example.ui.navigation.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class VaultViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val vaultDao = database.vaultDao()
    val repository = VaultRepository(application, vaultDao)
    val appLockRepository = AppLockRepository(application, vaultDao)
    val securityPrefs = SecurityPreferences(application)

    private val _isUnlocked = MutableStateFlow(!securityPrefs.isPinSet)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val backStack = ArrayDeque<Screen>()
    private val _currentScreen = MutableStateFlow<Screen>(
        if (!securityPrefs.isPinSet) Screen.SetupPin(isChangePin = false) else Screen.Lock
    )
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _language = MutableStateFlow(securityPrefs.language)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _themeMode = MutableStateFlow(securityPrefs.themeMode)
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _flagSecureEnabled = MutableStateFlow(securityPrefs.flagSecureEnabled)
    val flagSecureEnabled: StateFlow<Boolean> = _flagSecureEnabled.asStateFlow()

    private val _biometricEnabled = MutableStateFlow(securityPrefs.biometricEnabled)
    val biometricEnabled: StateFlow<Boolean> = _biometricEnabled.asStateFlow()

    private val _autoLockTimeout = MutableStateFlow(securityPrefs.autoLockTimeoutSeconds)
    val autoLockTimeout: StateFlow<Int> = _autoLockTimeout.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    // Multi-selection state
    private val _selectedItemIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedItemIds: StateFlow<Set<Long>> = _selectedItemIds.asStateFlow()

    val isMultiSelectMode: StateFlow<Boolean> = MutableStateFlow(false).apply {
        // Will be derived or updated
    }

    // Installed apps
    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()
    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    val stats: StateFlow<VaultStats> = repository.statsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = VaultStats()
    )

    val photos: StateFlow<List<VaultItem>> = repository.photos.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val videos: StateFlow<List<VaultItem>> = repository.videos.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val documents: StateFlow<List<VaultItem>> = repository.documents.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allFiles: StateFlow<List<VaultItem>> = repository.allActiveItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val trashItems: StateFlow<List<VaultItem>> = repository.deletedItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val folders: StateFlow<List<VaultFolder>> = repository.allFolders.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val lockedApps: StateFlow<List<LockedApp>> = appLockRepository.lockedAppsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        loadInstalledApps()
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            backStack.addLast(_currentScreen.value)
            _currentScreen.value = screen
            clearSelection()
        }
    }

    fun navigateBack(): Boolean {
        clearSelection()
        if (backStack.isNotEmpty()) {
            _currentScreen.value = backStack.removeLast()
            return true
        }
        return false
    }

    fun unlockWithPin(pin: String): Boolean {
        val success = securityPrefs.verifyPin(pin)
        if (success) {
            _isUnlocked.value = true
            securityPrefs.isVaultLocked = false
            _currentScreen.value = Screen.Dashboard
            backStack.clear()
        }
        return success
    }

    fun unlockWithBiometric() {
        _isUnlocked.value = true
        securityPrefs.isVaultLocked = false
        _currentScreen.value = Screen.Dashboard
        backStack.clear()
    }

    fun lockVault() {
        _isUnlocked.value = false
        securityPrefs.isVaultLocked = true
        _currentScreen.value = Screen.Lock
        backStack.clear()
        clearSelection()
    }

    fun setupPin(pin: String, question: String, answer: String) {
        securityPrefs.setPin(pin)
        securityPrefs.setSecurityQuestionAndAnswer(question, answer)
        _isUnlocked.value = true
        securityPrefs.isVaultLocked = false
        _currentScreen.value = Screen.Dashboard
        backStack.clear()
        emitToast("PIN and recovery configured successfully")
    }

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (!securityPrefs.verifyPin(oldPin)) return false
        securityPrefs.setPin(newPin)
        emitToast("PIN updated successfully")
        return true
    }

    fun verifyRecoveryAnswer(answer: String): Boolean {
        return securityPrefs.verifySecurityAnswer(answer) || securityPrefs.verifyRecoveryKey(answer)
    }

    fun resetPin(newPin: String) {
        securityPrefs.setPin(newPin)
        _isUnlocked.value = true
        securityPrefs.isVaultLocked = false
        _currentScreen.value = Screen.Dashboard
        backStack.clear()
        emitToast("PIN reset successfully")
    }

    fun setLanguage(language: AppLanguage) {
        securityPrefs.language = language
        _language.value = language
    }

    fun setThemeMode(mode: String) {
        securityPrefs.themeMode = mode
        _themeMode.value = mode
    }

    fun setBiometricEnabled(enabled: Boolean) {
        securityPrefs.biometricEnabled = enabled
        _biometricEnabled.value = enabled
    }

    fun setFlagSecure(enabled: Boolean) {
        securityPrefs.flagSecureEnabled = enabled
        _flagSecureEnabled.value = enabled
    }

    fun setAutoLockTimeout(seconds: Int) {
        securityPrefs.autoLockTimeoutSeconds = seconds
        _autoLockTimeout.value = seconds
    }

    // Selection
    fun toggleSelection(id: Long) {
        val current = _selectedItemIds.value.toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
        } else {
            current.add(id)
        }
        _selectedItemIds.value = current
    }

    fun selectAll(ids: List<Long>) {
        _selectedItemIds.value = ids.toSet()
    }

    fun clearSelection() {
        _selectedItemIds.value = emptySet()
    }

    // Vault operations
    fun importUris(uris: List<Uri>, targetFolderId: Long? = null) {
        viewModelScope.launch {
            var successCount = 0
            for (uri in uris) {
                val result = repository.importFile(uri, targetFolderId)
                if (result.isSuccess) successCount++
            }
            emitToast("Imported $successCount item(s) to vault")
        }
    }

    fun softDelete(id: Long) {
        viewModelScope.launch {
            repository.softDelete(id)
            emitToast("Moved to Recycle Bin")
        }
    }

    fun softDeleteSelected() {
        val ids = _selectedItemIds.value
        viewModelScope.launch {
            for (id in ids) {
                repository.softDelete(id)
            }
            clearSelection()
            emitToast("Moved ${ids.size} item(s) to Recycle Bin")
        }
    }

    fun restoreFromTrash(id: Long) {
        viewModelScope.launch {
            repository.restoreFromTrash(id)
            emitToast("Restored from Recycle Bin")
        }
    }

    fun permanentlyDelete(item: VaultItem) {
        viewModelScope.launch {
            repository.permanentlyDelete(item)
            emitToast("Item deleted permanently")
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
            emitToast("Recycle Bin emptied")
        }
    }

    fun renameItem(id: Long, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            repository.renameItem(id, newName)
            emitToast("Item renamed")
        }
    }

    fun moveItemToFolder(id: Long, folderId: Long) {
        viewModelScope.launch {
            repository.moveItemToFolder(id, folderId)
            emitToast("Moved to folder")
        }
    }

    fun moveSelectedToFolder(folderId: Long) {
        val ids = _selectedItemIds.value
        viewModelScope.launch {
            for (id in ids) {
                repository.moveItemToFolder(id, folderId)
            }
            clearSelection()
            emitToast("Moved ${ids.size} item(s) to folder")
        }
    }

    fun restoreItemToDownloads(item: VaultItem, context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS
                )
                if (!downloadsDir.exists()) downloadsDir.mkdirs()

                var restoredFile = File(downloadsDir, item.fileName)
                var counter = 1
                while (restoredFile.exists()) {
                    val nameWithoutExt = item.fileName.substringBeforeLast('.')
                    val ext = item.fileName.substringAfterLast('.', "")
                    val extStr = if (ext.isNotEmpty()) ".$ext" else ""
                    restoredFile = File(downloadsDir, "${nameWithoutExt}_$counter$extStr")
                    counter++
                }

                val success = FileOutputStream(restoredFile).use { fos ->
                    repository.restoreItemToStream(item, fos)
                }

                withContext(Dispatchers.Main) {
                    if (success) {
                        emitToast("Restored to Downloads: ${restoredFile.name}")
                    } else {
                        emitToast("Failed to restore item")
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    emitToast("Restore error: ${e.message}")
                }
            }
        }
    }

    fun restoreSelectedToDownloads(context: Context) {
        val selectedIds = _selectedItemIds.value
        viewModelScope.launch(Dispatchers.IO) {
            var count = 0
            for (id in selectedIds) {
                val item = repository.getItemById(id) ?: continue
                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS
                )
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val restoredFile = File(downloadsDir, item.fileName)
                val success = FileOutputStream(restoredFile).use { fos ->
                    repository.restoreItemToStream(item, fos)
                }
                if (success) count++
            }
            withContext(Dispatchers.Main) {
                clearSelection()
                emitToast("Restored $count item(s) to Downloads")
            }
        }
    }

    fun createFolder(name: String, type: String = "GENERAL") {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.createFolder(name, type)
            emitToast("Folder created: $name")
        }
    }

    fun deleteFolder(folder: VaultFolder) {
        viewModelScope.launch {
            repository.deleteFolder(folder)
            emitToast("Folder removed")
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            val lockedMap = appLockRepository.lockedAppsFlow.stateIn(viewModelScope).value
                .associate { it.packageName to it.isLocked }
            val apps = appLockRepository.getInstalledAppsList(lockedMap)
            _installedApps.value = apps
            _isLoadingApps.value = false
        }
    }

    fun toggleAppLock(packageName: String, appName: String, isLocked: Boolean) {
        viewModelScope.launch {
            appLockRepository.toggleLock(packageName, appName, isLocked)
            _installedApps.value = _installedApps.value.map {
                if (it.packageName == packageName) it.copy(isLocked = isLocked) else it
            }
            emitToast(if (isLocked) "$appName locked" else "$appName unlocked")
        }
    }

    private fun emitToast(msg: String) {
        viewModelScope.launch {
            _toastMessage.emit(msg)
        }
    }
}
