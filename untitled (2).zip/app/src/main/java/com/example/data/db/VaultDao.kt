package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.LockedApp
import com.example.data.model.VaultFolder
import com.example.data.model.VaultItem
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {
    // --- Vault Items ---
    @Query("SELECT * FROM vault_items WHERE isDeleted = 0 ORDER BY createdAt DESC")
    fun getAllActiveItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE fileType = :fileType AND isDeleted = 0 ORDER BY createdAt DESC")
    fun getItemsByType(fileType: String): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE folderId = :folderId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun getItemsByFolder(folderId: Long): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun getDeletedItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): VaultItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: VaultItem): Long

    @Update
    suspend fun updateItem(item: VaultItem)

    @Query("UPDATE vault_items SET isDeleted = 1, deletedAt = :timestamp WHERE id = :id")
    suspend fun softDeleteItem(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE vault_items SET isDeleted = 0, deletedAt = NULL WHERE id = :id")
    suspend fun restoreItem(id: Long)

    @Query("UPDATE vault_items SET folderId = :targetFolderId WHERE id = :id")
    suspend fun moveItemToFolder(id: Long, targetFolderId: Long)

    @Query("UPDATE vault_items SET fileName = :newName WHERE id = :id")
    suspend fun renameItem(id: Long, newName: String)

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun permanentlyDeleteItem(id: Long)

    @Query("DELETE FROM vault_items WHERE isDeleted = 1")
    suspend fun emptyTrash()

    @Query("SELECT COUNT(*) FROM vault_items WHERE isDeleted = 0")
    fun getTotalActiveCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM vault_items WHERE fileType = :type AND isDeleted = 0")
    fun getCountByType(type: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM vault_items WHERE isDeleted = 1")
    fun getTrashCount(): Flow<Int>

    @Query("SELECT SUM(fileSize) FROM vault_items WHERE isDeleted = 0")
    fun getTotalSizeBytes(): Flow<Long?>

    // --- Vault Folders ---
    @Query("SELECT * FROM vault_folders ORDER BY isSystem DESC, name ASC")
    fun getAllFolders(): Flow<List<VaultFolder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: VaultFolder): Long

    @Delete
    suspend fun deleteFolder(folder: VaultFolder)

    @Query("SELECT * FROM vault_folders WHERE id = :id LIMIT 1")
    suspend fun getFolderById(id: Long): VaultFolder?

    // --- Locked Apps ---
    @Query("SELECT * FROM locked_apps ORDER BY appName ASC")
    fun getAllLockedApps(): Flow<List<LockedApp>>

    @Query("SELECT * FROM locked_apps WHERE isLocked = 1")
    fun getActiveLockedApps(): Flow<List<LockedApp>>

    @Query("SELECT * FROM locked_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun getLockedApp(packageName: String): LockedApp?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLockedApp(lockedApp: LockedApp)

    @Query("DELETE FROM locked_apps WHERE packageName = :packageName")
    suspend fun deleteLockedApp(packageName: String)
}
