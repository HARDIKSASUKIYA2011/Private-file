package com.example.ui.navigation

sealed class Screen {
    data object Lock : Screen()
    data class SetupPin(val isChangePin: Boolean = false) : Screen()
    data object Recovery : Screen()
    data object Dashboard : Screen()
    data class Photos(val folderId: Long? = null) : Screen()
    data class Videos(val folderId: Long? = null) : Screen()
    data class Documents(val folderId: Long? = null) : Screen()
    data class Files(val folderId: Long? = null) : Screen()
    data object Folders : Screen()
    data object Trash : Screen()
    data object AppLock : Screen()
    data object Settings : Screen()
    data class PhotoViewer(val itemId: Long) : Screen()
    data class VideoPlayer(val itemId: Long) : Screen()
    data class DocumentViewer(val itemId: Long) : Screen()
}
