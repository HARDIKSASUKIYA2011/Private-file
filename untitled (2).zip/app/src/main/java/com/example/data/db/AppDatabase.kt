package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.LockedApp
import com.example.data.model.VaultFolder
import com.example.data.model.VaultItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [VaultItem::class, VaultFolder::class, LockedApp::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vaultDao(): VaultDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "panda_vault.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Prepopulate default system folders
                            CoroutineScope(Dispatchers.IO).launch {
                                val dao = getInstance(context).vaultDao()
                                dao.insertFolder(VaultFolder(id = 1, name = "Photos", type = "PHOTO", iconName = "photo", isSystem = true))
                                dao.insertFolder(VaultFolder(id = 2, name = "Videos", type = "VIDEO", iconName = "video", isSystem = true))
                                dao.insertFolder(VaultFolder(id = 3, name = "Documents", type = "DOCUMENT", iconName = "document", isSystem = true))
                                dao.insertFolder(VaultFolder(id = 4, name = "Personal", type = "GENERAL", iconName = "lock", isSystem = true))
                                dao.insertFolder(VaultFolder(id = 5, name = "Other", type = "GENERAL", iconName = "folder", isSystem = true))
                            }
                        }
                    })
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
