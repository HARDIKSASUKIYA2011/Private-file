package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.VaultItem
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CreateFolderDialog
import com.example.ui.components.FolderSelectDialog
import com.example.ui.components.RenameDialog
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaGold
import com.example.ui.theme.PandaRose
import com.example.ui.viewmodel.VaultViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentViewerScreen(
    viewModel: VaultViewModel,
    itemId: Long,
    language: AppLanguage,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val folders by viewModel.folders.collectAsState()
    var item by remember { mutableStateOf<VaultItem?>(null) }
    var tempFile by remember { mutableStateOf<File?>(null) }
    var textContent by remember { mutableStateOf<String?>(null) }
    var isTextFile by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }

    var showRenameDialog by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(itemId) {
        withContext(Dispatchers.IO) {
            val vaultItem = viewModel.repository.getItemById(itemId)
            item = vaultItem
            if (vaultItem != null) {
                val file = viewModel.repository.decryptToTempFile(vaultItem)
                tempFile = file
                val ext = vaultItem.fileName.substringAfterLast('.', "").lowercase()
                val textExts = listOf("txt", "md", "json", "xml", "csv", "log", "html", "kt", "java", "py", "c", "cpp")
                if (ext in textExts || vaultItem.mimeType.startsWith("text/")) {
                    isTextFile = true
                    textContent = file?.readText()
                } else {
                    isTextFile = false
                }
            }
            withContext(Dispatchers.Main) {
                isLoading = false
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            tempFile?.delete()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = {
                    Text(
                        text = item?.fileName ?: Strings.get("nav_documents", language),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showRenameDialog = true }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Rename")
                    }
                    IconButton(onClick = { showFolderDialog = true }) {
                        Icon(imageVector = Icons.Default.DriveFileMove, contentDescription = "Move")
                    }
                    IconButton(onClick = {
                        item?.let { viewModel.restoreItemToDownloads(it, context) }
                    }) {
                        Icon(imageVector = Icons.Default.Restore, contentDescription = "Restore", tint = BambooEmerald)
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = PandaRose)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = BambooEmerald)
                } else if (isTextFile && textContent != null) {
                    // In-app Text / Code Reader
                    Card(
                        modifier = Modifier.fillMaxSize(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        SelectionContainer {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp)
                                    .verticalScroll(rememberScrollState())
                                    .horizontalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = textContent!!,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else if (item != null) {
                    // Document Details & External Reader Launcher Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(PandaGold.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = PandaGold,
                                    modifier = Modifier.size(40.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = item!!.fileName,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "${formatFileSize(item!!.fileSize)} • ${item!!.mimeType}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            Button(
                                onClick = {
                                    tempFile?.let { file ->
                                        try {
                                            val uri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                file
                                            )
                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(uri, item!!.mimeType)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Open Document"))
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BambooEmerald),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("open_with_viewer_button")
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Open with Viewer", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    item?.let { currentItem ->
        if (showRenameDialog) {
            RenameDialog(
                initialName = currentItem.fileName,
                language = language,
                onDismiss = { showRenameDialog = false },
                onConfirm = { newName ->
                    viewModel.renameItem(currentItem.id, newName)
                    item = currentItem.copy(fileName = newName)
                    showRenameDialog = false
                }
            )
        }

        if (showFolderDialog) {
            FolderSelectDialog(
                folders = folders,
                language = language,
                onDismiss = { showFolderDialog = false },
                onSelectFolder = { folderId ->
                    viewModel.moveItemToFolder(currentItem.id, folderId)
                    showFolderDialog = false
                },
                onCreateFolder = {
                    showFolderDialog = false
                    showCreateFolderDialog = true
                }
            )
        }

        if (showCreateFolderDialog) {
            CreateFolderDialog(
                language = language,
                onDismiss = { showCreateFolderDialog = false },
                onConfirm = { folderName ->
                    viewModel.createFolder(folderName, "DOCUMENT")
                    showCreateFolderDialog = false
                }
            )
        }

        if (showDeleteConfirm) {
            ConfirmDeleteDialog(
                title = Strings.get("delete", language),
                message = Strings.get("file_deleted", language),
                language = language,
                onDismiss = { showDeleteConfirm = false },
                onConfirm = {
                    viewModel.softDelete(currentItem.id)
                    showDeleteConfirm = false
                    onBackClick()
                }
            )
        }
    }
}
